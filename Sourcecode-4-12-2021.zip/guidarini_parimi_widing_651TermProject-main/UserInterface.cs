﻿// ********************************************************************************
// Course: CSCI 651
// Instructor: Hou
//
// Programmers: Adam Guidarini, Ooha Parimi, Daniel Widing
// Z-IDs:       Z-1891236     , Z-1911845  , Z-1838064
//
// Project: Term Final Project
//
// File: UserInterface
// Purpose: Contorls the dynamic form objects for the user interface
// ********************************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace guidarini_parimi_widing_651TermProject
{
    public partial class UserInterface : Form
    {
        public UserInterface()
        {
            InitializeComponent();
        }
    }
}
