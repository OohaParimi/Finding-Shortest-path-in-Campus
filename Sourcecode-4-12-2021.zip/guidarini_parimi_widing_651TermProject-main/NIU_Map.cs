﻿// ********************************************************************************
// Course: CSCI 651
// Instructor: Hou
//
// Programmers: Adam Guidarini, Ooha Parimi, Daniel Widing
// Z-IDs:       Z-1891236     , Z-1911845  , Z-1838064
//
// Project: Term Final Project
//
// File: NIU_Map.cs
// Purpose: 
// ********************************************************************************

using System;
using System.Collections.Generic;
using System.Text;

namespace guidarini_parimi_widing_651TermProject
{
    class NIU_Map
    {
        public static Graph NiuMap()
        {
            Graph map = new Graph();

            // Create a Lists of Buildings, Intersections, and Edges
            List<Building> buildings = new List<Building>();
            List<Intersection> intersections = new List<Intersection>();
            List<Edge> edges = new List<Edge>();

            buildings.Add(new Building("B000", "Founders Memorial Library", "217 Normal Rd, DeKalb, IL 60115", 41.9340234067138, -88.76636228242835));
            buildings.Add(new Building("B001", "Holmes Student Center", "340 Carroll Ave, DeKalb, IL 60115", 41.935514781777364, -88.76688686929283));
            buildings.Add(new Building("B002", "Swen Parson Hall", "350 Normal Rd, DeKalb, IL 60115", 41.93436403548977, -88.76532561930946));
            buildings.Add(new Building("B003", "Psychology - Computer Science Building", "100 Normal Rd, DeKalb, IL 60115", 41.931671487857834, -88.76508011631934));
            buildings.Add(new Building("B004", "Davis Hall", "218 Normal Rd, DeKalb, IL 60115", 41.933352242592036, -88.76534279836089));
            buildings.Add(new Building("B005", "LaTourette Hall", "202 Normal Rd, DeKalb, IL 60115", 41.93275125500277, -88.76535315260868));
            buildings.Add(new Building("B006", "Montgomery Hall", "155 Castle Drive DeKalb, IL 60115", 41.93182902997411, -88.76360255284906));
            buildings.Add(new Building("B007", "Faraday Hall", "200 Normal RoadDeKalb, IL 60115", 41.93286181250744, -88.7644636783793));
            buildings.Add(new Building("B008", "Altgeld Hall", "595 College Avenue DeKalb, IL 60115", 41.9345837715111, -88.763971359123));

            intersections.Add(new Intersection("I000", 41.9345063903936, -88.76649429197141));
            intersections.Add(new Intersection("I001", 41.93463458049411, -88.76649342836383));
            intersections.Add(new Intersection("I002", 41.934930386371924, -88.7664494298038));
            intersections.Add(new Intersection("I003", 41.93504823687783, -88.76639074565469));
            intersections.Add(new Intersection("I004", 41.93464729168164, -88.76584473648286));
            intersections.Add(new Intersection("I005", 41.934520998586216, -88.76584666672728));
            intersections.Add(new Intersection("I006", 41.934639141407594, -88.7656565897783));
            intersections.Add(new Intersection("I007", 41.93438827401818, -88.76566035289962));
            intersections.Add(new Intersection("I008", 41.9336820295465, -88.76566171524398));
            intersections.Add(new Intersection("I009", 41.93287915418344, -88.76562361508796));
            intersections.Add(new Intersection("I010", 41.93266003164261, -88.76561903091782));
            intersections.Add(new Intersection("I011", 41.932663919719964, -88.76561377330937));
            intersections.Add(new Intersection("I012", 41.93217396621976, -88.76561494373499));
            intersections.Add(new Intersection("I013", 41.931847928797865, -88.7656245421987));
            intersections.Add(new Intersection("I014", 41.93161347300995, -88.76532234884607));
            intersections.Add(new Intersection("I015", 41.93142058722186, -88.76562389475147));
            intersections.Add(new Intersection("I016", 41.93168405170501, -88.7650799994264));
            intersections.Add(new Intersection("I017", 41.9319359596955, -88.76485477857666));
            intersections.Add(new Intersection("I018", 41.9320123864441, -88.76512919388482));
            intersections.Add(new Intersection("I019", 41.93366312093807, -88.76540764773276));
            intersections.Add(new Intersection("I020", 41.93335354883458, -88.765400995058));
            intersections.Add(new Intersection("I021", 41.93304809717384, -88.76538002129244));
            intersections.Add(new Intersection("I022", 41.93275590789165, -88.76541037532655));
            intersections.Add(new Intersection("I023", 41.93191355013882, -88.76396110051874));
            intersections.Add(new Intersection("I024", 41.932283912239335, -88.76392856845065));
            intersections.Add(new Intersection("I025", 41.93274035542957, -88.76401415516652));
            intersections.Add(new Intersection("I026", 41.932636967343164, -88.76440089875051));
            intersections.Add(new Intersection("I027", 41.932364394292435, -88.76492062425615));
            intersections.Add(new Intersection("I028", 41.932275279255826, -88.76518024129666));
            intersections.Add(new Intersection("I029", 41.932750107169056, -88.76492665030248));
            intersections.Add(new Intersection("I030", 41.93294957318394, -88.76491637717216));
            intersections.Add(new Intersection("I031", 41.93307002500273, -88.76493493553875));
            intersections.Add(new Intersection("I032", 41.93309419047487, -88.7643830975276));
            intersections.Add(new Intersection("I033", 41.93308996128466, -88.76401752849688));
            intersections.Add(new Intersection("I034", 41.933444932194455, -88.76494408095812));
            intersections.Add(new Intersection("I035", 41.93367305829808, -88.76494047888936));
            intersections.Add(new Intersection("I036", 41.934216247412046, -88.76493583657856));
            intersections.Add(new Intersection("I037", 41.934550033458606, -88.76494090951587));
            intersections.Add(new Intersection("I038", 41.93488772927122, -88.76495105050647));
            intersections.Add(new Intersection("I039", 41.934888306649505, -88.76566152366617));

            edges.Add(new Edge("E000", 125, buildings[0], intersections[0]));
            edges.Add(new Edge("E001", 14, intersections[0], intersections[1]));
            edges.Add(new Edge("E002", 108, intersections[1], intersections[2]));
            edges.Add(new Edge("E003", 50, intersections[2], intersections[3]));
            edges.Add(new Edge("E004", 108, intersections[3], buildings[1]));
            edges.Add(new Edge("E005", 170, intersections[1], intersections[4]));
            edges.Add(new Edge("E006", 170, intersections[0], intersections[5]));
            edges.Add(new Edge("E007", 14, intersections[5], intersections[4]));
            edges.Add(new Edge("E008", 55, intersections[4], intersections[6]));
            edges.Add(new Edge("E009", 100, intersections[6], intersections[7]));
            edges.Add(new Edge("E010", 15, intersections[7], buildings[2]));
            edges.Add(new Edge("E011", 77, intersections[7], intersections[8]));
            edges.Add(new Edge("E012", 290, intersections[8], intersections[9]));
            edges.Add(new Edge("E013", 44, intersections[9], intersections[10]));
            edges.Add(new Edge("E014", 44, intersections[10], intersections[11]));
            edges.Add(new Edge("E015", 178, intersections[11], intersections[12]));
            edges.Add(new Edge("E016", 119, intersections[12], intersections[13]));
            edges.Add(new Edge("E017", 118, intersections[13], intersections[14]));
            edges.Add(new Edge("E018", 155, intersections[13], intersections[15]));
            edges.Add(new Edge("E019", 106, intersections[14], intersections[15]));
            edges.Add(new Edge("E020", 76, intersections[14], intersections[16]));
            edges.Add(new Edge("E021", 15, intersections[16], buildings[3]));
            edges.Add(new Edge("E022", 98, intersections[16], intersections[17]));
            edges.Add(new Edge("E023", 74, intersections[17], intersections[18]));
            edges.Add(new Edge("E024", 136, intersections[13], intersections[18]));
            edges.Add(new Edge("E025", 143, intersections[12], intersections[18]));
            edges.Add(new Edge("E026", 68, intersections[8], intersections[19]));
            edges.Add(new Edge("E027", 115, intersections[19], intersections[20]));
            edges.Add(new Edge("E028", 119, intersections[20], intersections[21]));
            edges.Add(new Edge("E029", 78, intersections[9], intersections[21]));
            edges.Add(new Edge("E030", 17, intersections[20], buildings[4]));
            edges.Add(new Edge("E031", 96, intersections[21], intersections[22]));
            edges.Add(new Edge("E032", 66, intersections[9], intersections[22]));
            edges.Add(new Edge("E033", 59, intersections[10], intersections[22]));
            edges.Add(new Edge("E034", 66, intersections[11], intersections[22]));
            edges.Add(new Edge("E035", 10, intersections[22], buildings[5]));
            edges.Add(new Edge("E036", 238, intersections[17], intersections[23]));
            edges.Add(new Edge("E037", 236, buildings[3], intersections[23]));
            edges.Add(new Edge("E038", 59, intersections[23], buildings[6]));
            edges.Add(new Edge("E039", 135, intersections[23], intersections[24]));
            edges.Add(new Edge("E040", 29, intersections[24], buildings[6]));
            edges.Add(new Edge("E041", 266, intersections[18], intersections[24]));
            edges.Add(new Edge("E042", 168, intersections[24], intersections[25]));
            edges.Add(new Edge("E043", 123, intersections[25], intersections[26]));
            edges.Add(new Edge("E044", 5, intersections[26], buildings[7]));
            edges.Add(new Edge("E045", 275, intersections[26], intersections[27]));
            edges.Add(new Edge("E046", 73, intersections[27], intersections[28]));
            edges.Add(new Edge("E047", 120, intersections[012], intersections[28]));
            edges.Add(new Edge("E048", 15, intersections[28], buildings[5]));
            edges.Add(new Edge("E049", 142, intersections[27], intersections[29]));
            edges.Add(new Edge("E050", 11, intersections[29], buildings[5]));
            edges.Add(new Edge("E051", 11, intersections[29], buildings[7]));
            edges.Add(new Edge("E052", 70, intersections[29], intersections[30]));
            edges.Add(new Edge("E053", 10, intersections[30], buildings[7]));
            edges.Add(new Edge("E054", 47, intersections[30], intersections[31]));
            edges.Add(new Edge("E055", 119, intersections[21], intersections[31]));
            edges.Add(new Edge("E056", 144, intersections[31], intersections[32]));
            edges.Add(new Edge("E057", 102, intersections[32], intersections[33]));
            edges.Add(new Edge("E058", 128, intersections[33], intersections[25]));
            edges.Add(new Edge("E059", 14, intersections[32], buildings[7]));
            edges.Add(new Edge("E060", 131, intersections[31], intersections[34]));
            edges.Add(new Edge("E062", 85, intersections[34], intersections[35]));
            edges.Add(new Edge("E063", 25, intersections[34], buildings[4]));
            edges.Add(new Edge("E064", 11, intersections[35], buildings[2]));
            edges.Add(new Edge("E065", 127, intersections[19], intersections[35]));
            edges.Add(new Edge("E066", 11, intersections[8], buildings[2]));
            edges.Add(new Edge("E067", 196, intersections[35], intersections[36]));
            edges.Add(new Edge("E068", 26, intersections[36], buildings[2]));
            edges.Add(new Edge("E069", 131, intersections[36], intersections[37]));
            edges.Add(new Edge("E070", 120, intersections[37], intersections[38]));
            edges.Add(new Edge("E071", 70, intersections[37], buildings[2]));
            edges.Add(new Edge("E072", 70, intersections[37], buildings[8]));
            edges.Add(new Edge("E073", 192, intersections[38], intersections[39]));
            edges.Add(new Edge("E074", 93, intersections[6], intersections[39]));

            // Add everting to the map
            foreach (Building building in buildings)
                map.AddBuilding(building);

            foreach (Intersection intersection in intersections)
                map.AddIntersection(intersection);

            foreach (Edge edge in edges)
                map.AddEdge(edge);

            return map;
        }
    }
}
