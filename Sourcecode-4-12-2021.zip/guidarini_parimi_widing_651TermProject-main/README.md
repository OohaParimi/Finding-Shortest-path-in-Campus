# guidarini_parimi_widing_651TermProject
Term project for CSCI 651 which creates a path-finding map of the NIU campus to find the shortest paths between classes.

By Adam Guidarini, Ooha Parimi, and Daniel Widing
