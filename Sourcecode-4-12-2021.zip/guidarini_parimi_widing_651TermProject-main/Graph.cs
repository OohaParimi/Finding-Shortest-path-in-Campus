﻿// ********************************************************************************
// Course: CSCI 651
// Instructor: Hou
//
// Programmers: Adam Guidarini, Ooha Parimi, Daniel Widing
// Z-IDs:       Z-1891236     , Z-1911845  , Z-1838064
//
// Project: Term Final Project
//
// File: Graph.cs 
// Purpose: Constructs a weighted graph
// ********************************************************************************

using System.Collections.Generic;

namespace guidarini_parimi_widing_651TermProject
{
    class Graph
    {
        private List<Building> buildings;
        private List<Intersection> intersections;
        private List<Edge> edges;

        public Graph()
        {
            buildings = new List<Building>();
            intersections = new List<Intersection>();
            edges = new List<Edge>();
        }

        public List<Building> GetBuildings() => buildings;
        public List<Intersection> GetIntersections() => intersections;
        public List<Edge> GetEdges() => edges;
        // Returns number of elements in buildings and intersections
        public int GetNumVertices() => buildings.Count + intersections.Count;

        // Returns a string of the given object's type
        public string GetVertexType(object vertex) => vertex.GetType().ToString();

        // Adds a new Building to List Buildings
        public void AddBuilding(Building building) => buildings.Add(building);

        // Adds a new Intersection to List Intersections
        public void AddIntersection(Intersection intersection) => intersections.Add(intersection);

        // Adds a new Edge to List Edges
        public void AddEdge(Edge edge)
        {
            object item1 = edge.Vertices.Item1;
            object item2 = edge.Vertices.Item2;

            // Add vertex on either side to respective neighbors List
            foreach (Intersection intersection in intersections)
            {
                if (item1.Equals(intersection))
                    intersection.AddNeighbor(item2);
                else if (item2.Equals(intersection))
                    intersection.AddNeighbor(item1);
            }

            foreach (Building building in buildings)
            {
                if (item1.Equals(building))
                    building.AddNeighbor(item2);
                else if (item2.Equals(building))
                    building.AddNeighbor(item1);
            }

            edges.Add(edge);
        }

        // Determines if to vertices are adjacent
        public bool AreAdjacent(string id1, string id2)
        {
            List<Edge> edgesOfId1 = new List<Edge>();

            // If id1 is conencted to an edge, add that to edgesOfId1 list
            foreach (Edge edge in edges)
            {
                if (edge.Vertices.Item1.Equals(id1) || edge.Vertices.Item2.Equals(id1))
                    edgesOfId1.Add(edge);
            }

            // Now check for id2 at either end of the Edges in edgesOdId1
            foreach (Edge edge in edgesOfId1)
            {
                // Return true if id2 is found
                if (edge.Vertices.Item1.Equals(id2) || edge.Vertices.Item2.Equals(id2))
                    return true;
            }

            return false;
        }
    }
}
